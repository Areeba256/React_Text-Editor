import "./App.css";
import Navbar from "./components/Navbar";
import UtilsInput from "./components/UtilsInput";
import Warning from "./components/Warning";
import About from "./components/About";
import React, { useState } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

function App() {
  const [mode, setMode] = useState("light");
  const [alert, setAlert] = useState(null);
  const showAlert = (message, type) => {
    setAlert({
      msg: message,
      type: type,
    });

    setTimeout(() => {
      setAlert(null);
    }, 1500);
  };
  const toggleMode = () => {
    if (mode === "light") {
      setMode("dark");
      document.body.style.backgroundColor = "#191D88";
      showAlert("Dark mode has been enabled", "success");
    } else {
      setMode("light");
      document.body.style.backgroundColor = "white";
      showAlert("Light mode has been enabled", "success");
    }
  };
  return (
    <>
      <Router>
        <Navbar
          aboutText="About Us"
          title="TextUtils"
          mode={mode}
          toggleMode={toggleMode}
        />
        <Warning alert={alert} />
        <div className="container">
          <Switch>
            <Route path="/About" element={<About />}>
              <About />
            </Route>

            <Route path="/" element={<UtilsInput />}>
              <UtilsInput
                heading="Write Here"
                mode={mode}
                showAlert={showAlert}
              ></UtilsInput>
            </Route>
          </Switch>
        </div>
      </Router>
    </>
  );
}

export default App;
