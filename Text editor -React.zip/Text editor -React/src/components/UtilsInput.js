import React, { useState } from "react";

export default function UtilsInput(props) {
  const handleUpClick = () => {
    let newText = Text.toUpperCase();
    setText(newText);
    props.showAlert("Converted to uppercase!", "success");
  };

  const handleLoClick = () => {
    let newText = Text.toLowerCase();
    setText(newText);
    props.showAlert("Converted to lowercase!", "success");
  };

  const [Text, setText] = useState("Enter Text Here");

  const handleOnChange = (event) => {
    console.log("On change");
    setText(event.target.value);
  };

  const handleCopy = () => {
    var text = document.getElementById("UtilsTextArea");
    text.select();
    navigator.clipboard.writeText(text.value);
    props.showAlert("Text Copied to clipboard!", "success");
  };

  const handleExtraSpaces = () => {
    let newText = Text.split(/[ ]+/); //javascript regExp
    setText(newText.join(" "));
    props.showAlert("Extra spaces cleared!", "success");
  };
  return (
    <>
      <div
        className="container"
        style={{ color: props.mode === "dark" ? "white" : "black" }}
      >
        <div class="form-group">
          <h1 className="my-2">{props.heading}</h1>
          <textarea
            className="form-control"
            id="UtilsTextArea"
            value={Text}
            rows="8"
            onChange={handleOnChange}
            style={{
              backgroundColor: props.mode === "dark" ? "#191D88" : "white",
              color: props.mode === "dark" ? "white" : "black",
            }}
          ></textarea>
        </div>

        <button className="btn btn-primary mt-3 mx-1" onClick={handleUpClick}>
          Convert to Upper Case
        </button>

        <button className="btn btn-primary mt-3 mx-1" onClick={handleLoClick}>
          Convert to Lower Case
        </button>

        <button className="btn btn-primary mt-3 mx-1" onClick={handleCopy}>
          Copy Text
        </button>

        <button
          className="btn btn-primary mt-3 mx-1"
          onClick={handleExtraSpaces}
        >
          Remove Extra Spaces
        </button>
      </div>

      <div
        className="container"
        style={{ color: props.mode === "dark" ? "white" : "black" }}
      >
        <h1 className="my-2">Your Text Summary</h1>
        <p>
          {" "}
          {Text.split(" ").length} Words {Text.length} Characters
        </p>

        <p>{Math.floor(0.08 * Text.split(" ").length)} Minutes Read</p>
      </div>
    </>
  );
}
